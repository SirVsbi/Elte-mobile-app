﻿using System;
using System.Collections.Generic;
using System.Text;

namespace CryTogether
{
    class Constants
    {
        public static string RestUrl = "http://192.168.1.4:8678/api/Breakdown/{0}";
    }
}
