﻿using System;
using System.Collections.Generic;
using System.Text;

namespace CryTogether.Models
{
    public class AuthNetwork
    {
        public string Name { get; set; }

        public string Icon { get; set; }

        public string Background { get; set; }

        public string Foreground { get; set; }
    }
}